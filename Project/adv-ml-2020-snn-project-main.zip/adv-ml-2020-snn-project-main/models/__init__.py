from .snn_models import IF_Network, LIF_Network, SRM0_Network, DiehlAndCook_Network
from .ann_models import ANN_Model

from . import snn_models, ann_models
